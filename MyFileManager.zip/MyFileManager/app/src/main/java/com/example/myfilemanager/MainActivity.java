package com.example.myfilemanager;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private static final int READ_REQUEST_CODE = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alayout);

    }

    class ListTextAdapt extends BaseAdapter {

        private List<String> listOfData = new ArrayList<String>();

        private boolean[] mySelection;

        public void setData(List<String> listOfData) {
            if(listOfData != null) {
                this.listOfData.clear();
                if(listOfData.size() > 0) {
                    this.listOfData.addAll(listOfData);
                }
                //Here we notify the BaseAdapter class that we have updated the data
                notifyDataSetChanged();
            }
        }

        void setMySelections(boolean[] mySelection) {
            if(mySelection != null) {
                this.mySelection = new boolean[mySelection.length];
                for(int i=0;i<mySelection.length;i++) {
                    this.mySelection[i] = mySelection[i];
                }
                notifyDataSetChanged();
            }
        }

        @Override
        public int getCount() {
            return listOfData.size();
        }

        @Override
        public String getItem(int position) {
            return listOfData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null) {
                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.listofitems,parent, false);
                convertView.setTag(new ViewData((TextView) convertView.findViewById(R.id.myTextItems)));
            }
            ViewData viewMyData = (ViewData) convertView.getTag();
            final String getsItemData = getItem(position);
            final int file_size = Integer.parseInt(String.valueOf(getsItemData.length()));
            viewMyData.info.setText("Name of file/folder: " +
                    getsItemData.substring(getsItemData.lastIndexOf('/')+1)
                    + "\n\n.....Size: " + file_size + " bytes.....");
            if (mySelection != null) {
                if (mySelection[position]) {
                    //the color is changed to light blue if selected
                    viewMyData.info.setBackgroundColor(Color.argb(229,229,204,255));
                } else {
                    //when user deselects, color changes to transparent
                    viewMyData.info.setBackgroundColor(Color.TRANSPARENT);
                }

            }
            return convertView;
        }

        //create class to see the list of data
        class ViewData {
            TextView info;

            ViewData(TextView info) {
                this.info = info;
            }
        }
    }
    //this can be any random higher number for checking permissions
    private static final int GET_USER_PERMISSIONS = 777;

    //We ask for permission from users at the beginning of the app
    private static final String[] ASKING_PERMISSIONS = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    private static final int NUMBER_OF_PERMISSIONS = 2;

    private boolean isPermissionOff() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int permission = 0;
            while (permission < NUMBER_OF_PERMISSIONS) {
                if(checkSelfPermission(ASKING_PERMISSIONS[permission]) != PackageManager.PERMISSION_GRANTED) {
                    return true;
                }
                permission++;
            }
        }
        return false;
    }

    private int num_of_files;
    private List<String> listOfFiles;
    private File[] filesArray;
    private boolean[] mySelection;

    //check for permission to see if we still have them on
    @Override
    protected void onResume() {
        super.onResume();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isPermissionOff()) {
            //requesting permissions from users
            requestPermissions(ASKING_PERMISSIONS, NUMBER_OF_PERMISSIONS);
            return;
        }
        final String defaultPath = String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS));
        final File files = new File(defaultPath);
        filesArray = files.listFiles();
        final TextView filesToDisplay = findViewById(R.id.pathFiles);

        //get available storage space for users
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long bytesAvailable = (long)stat.getBlockSize() *(long)stat.getBlockCount();

        filesToDisplay.setText("Current folder: " + defaultPath + "\nStorage Remaining: " +
                bytesAvailable + " KB");

        num_of_files = filesArray.length;

        final ListView listView = findViewById(R.id.myListView);
        final ListTextAdapt myListTextAdaptOne = new ListTextAdapt();
        listView.setAdapter(myListTextAdaptOne);

        listOfFiles = new ArrayList<String>();

        for(int i=0;i<num_of_files;i++) {
            listOfFiles.add(String.valueOf(filesArray[i].getAbsolutePath()));
        }
        myListTextAdaptOne.setData(listOfFiles);
        mySelection = new boolean[filesArray.length];

        //when onClick (Long Click) pressed, we select the item; else, unselect
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                mySelection[position] =! mySelection[position];
                myListTextAdaptOne.setMySelections(mySelection);
                return false;
            }
        });

        //Share file using internal system software
        final Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Get total memory storage in KB
                StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                long bytesAvai = (long)stat.getBlockSize() *(long)stat.getBlockCount();

                Uri pictureUri = Uri.parse(defaultPath);
                String text = "Picture Description: A flower is a special part of the plant." +
                        "Flowers are also called the bloom or blossom of a plant." +
                        "Flowers have petals. Inside the part of the flower that has petals are" +
                        "the parts which produce pollen and seeds. In all plants, a flower is " +
                        "usually its most colourful part." + "\nPicture Detail: "
                        + defaultPath + "\n" + "Storage Size Left (KB): " + bytesAvai;
                Intent shareIntent = new Intent();
                shareIntent.setAction(Intent.ACTION_SEND);
                shareIntent.putExtra(Intent.EXTRA_TEXT, text);
                shareIntent.putExtra(Intent.EXTRA_STREAM, pictureUri);
                shareIntent.setType("image/*");
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share images..."));
            }
        });

        //Delete files/folders
        final Button button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //show the dialog box for users for delete of files/folders
                AlertDialog.Builder delAlert = new AlertDialog.Builder(MainActivity.this);
                //Header line
                delAlert.setTitle("Delete Me");
                //Message box
                delAlert.setMessage("Click Delete to permanently delete your selection(s)");
                //delete action
                delAlert.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for (int i=0; i<filesArray.length; i++) {
                            if (mySelection[i]) {
                                delSelections(filesArray[i]);
                            }
                        }
                        filesArray = files.listFiles();
                        num_of_files = filesArray.length;
                        listOfFiles.clear();
                        for(int i=0;i<num_of_files;i++) {
                            listOfFiles.add(String.valueOf(filesArray[i].getAbsolutePath()));
                        }
                        myListTextAdaptOne.setData(listOfFiles);
                    }
                });
                delAlert.setNegativeButton("Cancel Action", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                delAlert.show();
            }

        });

        //Create new folder
        final Button makeNewFolder = findViewById(R.id.button2);
        makeNewFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder makeNewFolderDialog = new AlertDialog.Builder(MainActivity.this);
                makeNewFolderDialog.setTitle("Create New Folder");
                final EditText userText = new EditText(MainActivity.this);
                makeNewFolderDialog.setView(userText);
                makeNewFolderDialog.setPositiveButton("Done", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        final File newDir = new File(defaultPath + "/" + userText.getText());
                        newDir.mkdir();
                        filesArray = files.listFiles();
                        num_of_files = filesArray.length;
                        listOfFiles.clear();
                        for(int i=0;i<num_of_files;i++) {
                            listOfFiles.add(String.valueOf(filesArray[i].getAbsolutePath()));
                        }
                        myListTextAdaptOne.setData(listOfFiles);
                    }

                });
                makeNewFolderDialog.setNegativeButton("Cancel Action", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                makeNewFolderDialog.show();
            }
        });
    }

    //method to delete user selections
    private void delSelections(File thoseSelections) {
        if (thoseSelections.isDirectory()) {
            if (thoseSelections.list().length == 0) {
                thoseSelections.delete();
            } else {
                String showThoseFiles[] = thoseSelections.list();
                for (String variable : showThoseFiles) {
                    File deleteThoseFiles = new File(thoseSelections, variable);
                    thoseSelections.delete();
                }
                //delete itself after inner deletion
                if (thoseSelections.list().length == 0) {
                    thoseSelections.delete();
                }
            }
        } else {
            thoseSelections.delete();
        }
    }

    //read content of the file
    private String readText (String input) {
        File file = new File(input);
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null)  {
                text.append(line);
                text.append("\n");
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return text.toString();
    }

    //select file from storage
    private void performFileSearch() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/*");
        startActivityForResult(intent, READ_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Uri uri1 = data.getData();
                String path = uri1.getPath();
                path = path.substring(path.indexOf(":") + 1);
                Toast.makeText(this, "" + path, Toast.LENGTH_SHORT).show();

            }
        }
    }

    //checking for user's permissions enable/disable
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onRequestPermissionsResult(final int getPermissionCode,  final String[] permissions, final int[] acceptUser) {
        super.onRequestPermissionsResult(getPermissionCode,permissions,acceptUser);
        if (getPermissionCode == NUMBER_OF_PERMISSIONS && acceptUser.length > 0) {
            //check if the permissions are not accepted
            if (isPermissionOff()) {
                //users have to accept the permission, else clears data
                ((ActivityManager) Objects.requireNonNull(this.getSystemService(ACTIVITY_SERVICE))).clearApplicationUserData();
                recreate();
            } else {
                onResume();
            }
        }
    }
}
